CAREER POINT – PC CLASSES WEBSITE v2
Features:
- Premium responsive design
- Animated/hover interactions
- WhatsApp button
- Call buttons
- Admission form -> opens WhatsApp with student details
- Gallery
- Reviews
- Class 11 & 12 programs without old batch dates/times
- Google Maps button
- Supplied coaching images and banner

Keep the assets folder next to index.html.
Open index.html to preview.
Upload the entire folder to static hosting to publish.
